<?php 
require_once('auth.php');
include('../connect.php');
?>
<?php  
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM products";
 $result = mysqli_query($connect,$query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th>ProductId</th>  
                         <th>Product Code</th>  
                         <th>Category</th>  
       <th>Selling Price</th>
       <th>Supplier </th>
           <th>Qty</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["product_id"].'</td>  
                         <td>'.$row["product_code"].'</td>  
                         <td>'.$row["gen_name"].'</td>  
       <td>'.$row["price"].'</td>  
       <td>'.$row["supplier"].'</td>
         <td>'.$row["qty"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
